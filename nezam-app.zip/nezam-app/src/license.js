// تایید کد دسترسی کاملاً آفلاین با امضای دیجیتال (Ed25519). فقط کلید عمومی داخل اپ است.
import nacl from 'tweetnacl';
import { decodeBase64, encodeUTF8 } from 'tweetnacl-util';
import * as SecureStore from 'expo-secure-store';
import * as Application from 'expo-application';
import { Platform } from 'react-native';

export const PUBLIC_KEY = 'PASTE_PUBLIC_KEY_HERE'; // خروجی npm run keys

export async function getDeviceId() {
  return Platform.OS === 'android' ? Application.getAndroidId() : await Application.getIosIdForVendorAsync();
}

export async function activate(code) {
  try {
    const [p, s] = code.trim().split('.');
    const ok = nacl.sign.detached.verify(decodeBase64(p), decodeBase64(s), decodeBase64(PUBLIC_KEY));
    if (!ok) return { ok: false, msg: 'کد نامعتبر است' };
    const d = JSON.parse(encodeUTF8(decodeBase64(p)));
    if (d.d !== (await getDeviceId())) return { ok: false, msg: 'این کد برای گوشی دیگری صادر شده' };
    if (Date.now() > d.e) return { ok: false, msg: 'کد منقضی شده' };
    await SecureStore.setItemAsync('license', code.trim());
    return { ok: true };
  } catch { return { ok: false, msg: 'کد نامعتبر است' }; }
}

// بررسی هر بار باز شدن اپ؛ با ضد برگرداندن ساعت گوشی
export async function checkLicense() {
  const code = await SecureStore.getItemAsync('license');
  if (!code) return { ok: false, msg: '' };
  const r = await activate(code);
  if (!r.ok) return r;
  const last = Number(await SecureStore.getItemAsync('lastSeen')) || 0;
  if (Date.now() < last - 3600e3) return { ok: false, msg: 'ساعت گوشی دستکاری شده است' };
  await SecureStore.setItemAsync('lastSeen', String(Math.max(last, Date.now())));
  const d = JSON.parse(encodeUTF8(decodeBase64(code.split('.')[0])));
  return { ok: true, expires: d.e };
}
