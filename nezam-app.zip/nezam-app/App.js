import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet, SafeAreaView, Alert, Share, I18nManager } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ScreenCapture from 'expo-screen-capture';
import * as Notifications from 'expo-notifications';
import Pdf from 'react-native-pdf';
import data from './src/data.json';
import { activate, checkLicense, getDeviceId } from './src/license';

I18nManager.allowRTL(true);
const C = { bg: '#F4F7FB', primary: '#1F4E79', accent: '#F2A33A', card: '#FFFFFF', ok: '#2E7D32', bad: '#C62828', text: '#1B2733' };

// نمره با فرمول «هر ۳ غلط، یک درست را خنثی می‌کند»
export const score = (c, w, n) => Math.max(0, ((c - w / 3) / n) * 100);

export default function App() {
  const [lic, setLic] = useState(null);
  const [screen, setScreen] = useState({ name: 'home' });
  const [done, setDone] = useState({});
  const [dev, setDev] = useState('');

  useEffect(() => {
    ScreenCapture.preventScreenCaptureAsync(); // Android: جلوی اسکرین‌شات و ضبط؛ iOS: ضبط را تشخیص می‌دهیم
    const sub = ScreenCapture.addScreenshotListener(() => Alert.alert('اسکرین‌شات مجاز نیست'));
    getDeviceId().then(setDev);
    checkLicense().then(setLic);
    AsyncStorage.getItem('done').then(v => v && setDone(JSON.parse(v)));
    (async () => {
      const p = await Notifications.requestPermissionsAsync();
      if (p.granted) {
        await Notifications.cancelAllScheduledNotificationsAsync();
        await Notifications.scheduleNotificationAsync({
          content: { title: 'وقت مطالعه است 📚', body: 'امروز یک آزمون یا چند صفحه بخوان؛ قدم‌به‌قدم تا قبولی.' },
          trigger: { hour: 20, minute: 0, repeats: true },
        });
      }
    })();
    return () => sub.remove();
  }, []);

  const saveDone = async (id, res) => { const n = { ...done, [id]: res }; setDone(n); await AsyncStorage.setItem('done', JSON.stringify(n)); };

  if (!lic) return <Center><Text>...</Text></Center>;
  if (!lic.ok) return <Activation dev={dev} msg={lic.msg} onOk={() => checkLicense().then(setLic)} />;
  if (screen.name === 'sub') return <Sub back={() => setScreen({ name: 'home' })} dev={dev} />;
  if (screen.name === 'pdf') return <PdfView item={screen.item} back={() => setScreen({ name: 'home' })} />;
  if (screen.name === 'exam') return <Exam item={screen.item} back={() => setScreen({ name: 'home' })} save={saveDone} />;
  if (screen.name === 'text') return <Page title={screen.item.title} back={() => setScreen({ name: 'home' })}><Text style={s.body}>{screen.item.body}</Text></Page>;

  const lockedNow = !!done.comp1; // بعد از آزمون جامع اول، مباحث قبلی قفل می‌شود
  const days = Math.ceil((lic.expires - Date.now()) / 864e5);
  return (
    <Page title="آزمون نظام مهندسی عمران">
      <View style={s.banner}><Text style={s.bannerT}>اشتراک: {days} روز مانده</Text>
        <TouchableOpacity onPress={() => setScreen({ name: 'sub' })}><Text style={s.link}>تمدید</Text></TouchableOpacity></View>
      {data.items.map(it => {
        const locked = (lockedNow && (it.topic || it.topicsLocked)) || (it.unlockAfter && !done[it.unlockAfter]);
        return (
          <TouchableOpacity key={it.id} disabled={locked} style={[s.card, locked && { opacity: 0.4 }]}
            onPress={() => setScreen({ name: it.kind, item: it })}>
            <View style={s.badge}><Text style={s.badgeT}>{it.group}</Text></View>
            <Text style={s.cardT}>{it.title}{locked ? '  🔒' : ''}</Text>
            {done[it.id] && <Text style={s.pct}>{done[it.id].pct.toFixed(0)}٪</Text>}
          </TouchableOpacity>
        );
      })}
    </Page>
  );
}

const Center = ({ children }) => <SafeAreaView style={[s.root, { justifyContent: 'center', alignItems: 'center' }]}>{children}</SafeAreaView>;
const Page = ({ title, back, children }) => (
  <SafeAreaView style={s.root}>
    <View style={s.header}>{back && <TouchableOpacity onPress={back}><Text style={s.headerT}>→</Text></TouchableOpacity>}<Text style={s.headerT}>{title}</Text></View>
    <ScrollView contentContainerStyle={{ padding: 14 }}>{children}</ScrollView>
  </SafeAreaView>
);

function Activation({ dev, msg, onOk }) {
  const [code, setCode] = useState('');
  return (
    <Page title="فعال‌سازی">
      <Text style={s.body}>شناسه دستگاه شما (برای ادمین ارسال کنید):</Text>
      <Text selectable style={s.devId}>{dev}</Text>
      <TextInput style={s.input} placeholder="کد دسترسی" value={code} onChangeText={setCode} autoCapitalize="none" multiline />
      {!!msg && <Text style={{ color: C.bad, textAlign: 'right' }}>{msg}</Text>}
      <Btn t="فعال‌سازی" onPress={async () => { const r = await activate(code); r.ok ? onOk() : Alert.alert(r.msg); }} />
      <Btn t="ارسال شناسه دستگاه" onPress={() => Share.share({ message: dev })} />
    </Page>
  );
}

function Sub({ back, dev }) {
  const x = data.subscription; // همه جزئیات از src/data.json توسط ادمین قابل تغییر است
  return (
    <Page title={x.title} back={back}>
      <Text style={s.cardT}>{x.price}</Text><Text style={s.body}>{x.description}</Text>
      {x.features.map(f => <Text key={f} style={s.body}>✓ {f}</Text>)}
      <Text style={s.body}>ارتباط با ادمین: {x.contact}</Text>
      <Text selectable style={s.devId}>{dev}</Text>
    </Page>
  );
}

function PdfView({ item, back }) {
  const [page, setPage] = useState(1);
  useEffect(() => { AsyncStorage.getItem('pg:' + item.id).then(v => v && setPage(Number(v))); }, []);
  return (
    <SafeAreaView style={s.root}>
      <View style={s.header}><TouchableOpacity onPress={back}><Text style={s.headerT}>→</Text></TouchableOpacity><Text style={s.headerT}>{item.title}</Text></View>
      <Pdf source={{ uri: item.url, cache: true }} page={page} style={{ flex: 1 }}
        onPageChanged={p => { setPage(p); AsyncStorage.setItem('pg:' + item.id, String(p)); }} />
    </SafeAreaView>
  );
}

function Exam({ item, back, save }) {
  const [ans, setAns] = useState({});
  const [res, setRes] = useState(null);
  const [endAt] = useState(Date.now() + (item.durationMin || data.settings.defaultExamMinutes) * 60000);
  const [left, setLeft] = useState(Math.round((endAt - Date.now()) / 1000));
  const qs = item.questions;
  const finish = () => {
    let c = 0, w = 0;
    qs.forEach((q, i) => { if (ans[i] === undefined) return; ans[i] === q.a ? c++ : w++; });
    const r = { c, w, blank: qs.length - c - w, pct: score(c, w, qs.length) };
    setRes(r); save(item.id, r);
  };
  useEffect(() => {
    if (res || !qs.length) return;
    const t = setInterval(() => setLeft(Math.max(0, Math.round((endAt - Date.now()) / 1000))), 1000);
    return () => clearInterval(t);
  }, [res]);
  useEffect(() => { if (left <= 0 && !res && qs.length) finish(); }, [left]); // اتمام خودکار با پایان زمان
  const mmss = `${String(Math.floor(left / 60)).padStart(2, '0')}:${String(left % 60).padStart(2, '0')}`;
  if (!qs.length) return <Page title={item.title} back={back}><Text style={s.body}>هنوز سوالی بارگذاری نشده است.</Text></Page>;
  return (
    <Page title={item.title} back={back}>
      {!res && <Text style={s.timer}>⏱ زمان باقی‌مانده: {mmss}</Text>}
      {res && (
        <View style={s.card}><Text style={s.cardT}>درست {res.c} | غلط {res.w} | نزده {res.blank}</Text>
          <Text style={s.cardT}>نمره (با کسر منفی): {res.pct.toFixed(1)}٪</Text></View>
      )}
      {qs.map((q, i) => (
        <View key={i} style={s.q}>
          <Text style={s.cardT}>{i + 1}. {q.q}</Text>
          {q.o.map((o, j) => {
            const picked = ans[i] === j;
            const bg = res ? (j === q.a ? '#C8E6C9' : picked ? '#FFCDD2' : '#fff') : picked ? '#DCE9F7' : '#fff';
            return <TouchableOpacity key={j} disabled={!!res} onPress={() => setAns({ ...ans, [i]: j })} style={[s.opt, { backgroundColor: bg }]}>
              <Text style={s.body}>{j + 1}) {o}</Text></TouchableOpacity>;
          })}
        </View>
      ))}
      {!res && <Btn t="پایان آزمون" onPress={finish} />}
    </Page>
  );
}

const Btn = ({ t, onPress }) => <TouchableOpacity style={s.btn} onPress={onPress}><Text style={s.btnT}>{t}</Text></TouchableOpacity>;

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, padding: 16, backgroundColor: C.primary },
  headerT: { color: '#fff', fontSize: 18, fontWeight: '700' },
  banner: { flexDirection: 'row-reverse', justifyContent: 'space-between', backgroundColor: '#FFF4E0', padding: 12, borderRadius: 12, marginBottom: 10 },
  bannerT: { color: C.text }, link: { color: C.primary, fontWeight: '700' },
  card: { flexDirection: 'row-reverse', alignItems: 'center', backgroundColor: C.card, borderRadius: 14, padding: 14, marginBottom: 10, elevation: 2, gap: 10 },
  cardT: { flex: 1, textAlign: 'right', color: C.text, fontSize: 16, writingDirection: 'rtl' },
  badge: { width: 34, height: 34, borderRadius: 17, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center' },
  badgeT: { color: '#fff', fontWeight: '700' }, pct: { color: C.ok, fontWeight: '700' },
  body: { textAlign: 'right', color: C.text, fontSize: 15, lineHeight: 26, marginVertical: 4, writingDirection: 'rtl' },
  input: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginVertical: 12, textAlign: 'left', minHeight: 70 },
  devId: { backgroundColor: '#fff', padding: 10, borderRadius: 10, textAlign: 'center', fontSize: 16, marginVertical: 8 },
  btn: { backgroundColor: C.primary, borderRadius: 12, padding: 14, marginVertical: 6, alignItems: 'center' }, btnT: { color: '#fff', fontWeight: '700' },
  timer: { textAlign: 'center', fontSize: 18, fontWeight: '700', color: C.primary, marginBottom: 10 },
  q: { backgroundColor: C.card, borderRadius: 14, padding: 12, marginBottom: 12 },
  opt: { borderWidth: 1, borderColor: '#D5DEE9', borderRadius: 10, padding: 10, marginTop: 6 },
});
