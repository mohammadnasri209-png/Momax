const nacl = require('tweetnacl'), u = require('tweetnacl-util'), fs = require('fs');
const k = nacl.sign.keyPair();
fs.writeFileSync(__dirname + '/../keys/secret.key', u.encodeBase64(k.secretKey));
console.log('PUBLIC_KEY (در src/license.js بگذارید):\n' + u.encodeBase64(k.publicKey));
console.log('کلید خصوصی در keys/secret.key ذخیره شد. هرگز آن را در گیت نگذارید یا منتشر نکنید.');
