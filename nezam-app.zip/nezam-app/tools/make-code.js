// استفاده: node tools/make-code.js <شناسه-دستگاه> [تعداد-ماه=8]
const nacl = require('tweetnacl'), u = require('tweetnacl-util'), fs = require('fs');
const [dev, m = 8] = process.argv.slice(2);
if (!dev) { console.log('شناسه دستگاه را وارد کنید'); process.exit(1); }
const sk = u.decodeBase64(fs.readFileSync(__dirname + '/../keys/secret.key', 'utf8').trim());
const e = new Date(); e.setMonth(e.getMonth() + Number(m));
const msg = u.decodeUTF8(JSON.stringify({ d: dev, e: e.getTime(), v: 1 }));
console.log(u.encodeBase64(msg) + '.' + u.encodeBase64(nacl.sign.detached(msg, sk)));
console.log('انقضا:', e.toISOString());
