# اپ آزمون نظام مهندسی عمران (Expo)

## اجرا
npm install
npx expo run:android   # به‌خاطر react-native-pdf در Expo Go اجرا نمی‌شود (Dev Build لازم است)

## کلید و کد آفلاین
npm run keys                       # یک‌بار؛ کلید عمومی را در src/license.js بگذارید
npm run code -- <شناسه-دستگاه> 8   # صدور کد ۸ ماهه برای یک گوشی (بدون اینترنت و سرور)

## محتوا
همه چیز (آزمون‌ها، متن‌ها، لینک PDF، صفحه اشتراک) در src/data.json است.

## گیت‌هاب
git init && git add . && git commit -m "init"
git branch -M main && git remote add origin <آدرس-ریپو> && git push -u origin main
# keys/secret.key در .gitignore است؛ هرگز آن را push نکنید.

## ساخت APK
npm i -g eas-cli && eas build -p android --profile preview

## تنظیمات ادمین (src/data.json)
- settings.defaultExamMinutes: زمان پیش‌فرض آزمون (۱۲۰ دقیقه)؛ هر آزمون با durationMin جدا قابل تغییر است
- عنوان‌ها (title و group)، ترتیب آیتم‌ها و تعداد سوال‌ها بدون محدودیت قابل ویرایش است
- unlockAfter: آیتم بعد از انجام آیتم دیگر فعال می‌شود (مثلاً آزمون مباحث قبلی بعد از آزمون همان مبحث)
